Included are files for the "Intro to Shiny" Workshop
2017 UNC Biology Symposium
Presented by: Chris Payne 
Date: May 3, 2017

Files include:

IntroToShinyWorkshop-2017BioSymposium-payne.pptx
 > Introductory powerpoint

IntroToShinyWorkshop-payne2017.pdf
 > PDF of Shiny Exmaple Code Walkthrough

Example Code (folder)
 > Folder containing code used throughout "IntroToShinyWorkshop-payne2017.pdf"
 > Can more easily use this code using `source()` in rStudio.
 > Includes:

      IntroToShinyWorkshop - CO2 Example 1.R
      IntroToShinyWorkshop - CO2 Example 2.R
      IntroToShinyWorkshop - CO2 Example 3.R
      IntroToShinyWorkshop - CO2 Example 4.R
      IntroToShinyWorkshop - CO2 Example 5.R


