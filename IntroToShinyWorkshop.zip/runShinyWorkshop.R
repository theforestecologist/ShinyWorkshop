install.rmarkdown <- !("rmarkdown" %in% installed.packages()[,"Package"])
if(install.rmarkdown) install.packages("rmarkdown", repos="http://cran.rstudio.com/")
library(rmarkdown)
library(knitr)

rmarkdown::run("./IntroToShinyWorkshop.Rmd")