needed.packages <- c("shiny","rmarkdown","png")
install.packages <- needed.packages[!(needed.packages %in% installed.packages()[,"Package"])]
if(length(install.packages) > 0) install.packages(install.packages, repos="http://cran.rstudio.com/")
lapply(c(needed.packages,"knitr"), library, character.only = T)

rmarkdown::run("./IntroToShinyWorkshop.Rmd")
